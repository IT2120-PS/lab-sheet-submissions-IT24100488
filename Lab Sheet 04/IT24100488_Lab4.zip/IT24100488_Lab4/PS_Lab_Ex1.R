getwd()
##Part1
setwd("C:\\Users\\IT24100488\\Desktop\\IT24100488_Lab4")

data<-read.table("DATA 4.txt", header=TRUE, sep = " ")
fix(data)
attach(data)

##Part2

boxplot(X1,main="Box plot for Team Attendance",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)        
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

hist(X1,ylab="Frequency",xlab="Team Attendance",main="Histogram for Team Attendance")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Years",main="Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

MEDIAN(x1)
MEDIAN(x2)
MEDIAN(x3)

SD(X1)
SD(X2)
SD(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

IQR(X1)
IQR(2)
IQR(X3)

##Part3
get.mode<-fuction(y){
  counts<-table(X3)
  names(counts[counts == max(counts)])
}

get.mode(X3)

table(X3)

max(counts)

counts == max(counts)

counts[counts == max(counts)]

names(counts[counts == max(counts)])

##pART4
get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3+1.5*iqr
  lb <- q1-1.5*iqr
  
  print(paste("Upper Bound=",ub))
  print(paste("Lower Bound=",lb))
  print(paste("Outliers:",paste(sort(z[z<lb | z>ub]),collapse =",")))
}

get.outliers(X1)
get.outliers(X2)
get.outliers(X3)


