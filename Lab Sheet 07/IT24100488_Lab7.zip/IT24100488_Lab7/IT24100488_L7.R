getwd()
setwd("/Users/shana_venthan/Desktop/IT24100488_Lab7")

#Exercise
#01
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

#02
pexp(2, rate = 0.33, lower.tail = TRUE)

#03
#03.1
pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)

#03.2
qnorm(0.95,mean = 100, sd = 15 )
